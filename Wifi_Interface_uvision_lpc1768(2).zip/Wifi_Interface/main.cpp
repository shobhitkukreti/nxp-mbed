#include "mbed.h"
#include "WiflyInterface.h"
#include "SHTx/sht15.hpp"
#include "SHTx/i2c.hpp"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);
SHTx::SHT15 sensor(p6, p7);

Serial pc(USBTX, USBRX);
 
const char* ECHO_SERVER_ADDRESS = "10.0.0.4";
const int ECHO_SERVER_PORT = 5000;
char *out_buffer = "0 5001";
char temp[7];

WiflyInterface wifly(p9, p10, p25, p26, "HOME-2012","2A7FC553A4492C02", WPA);

int main() {
 sensor.setOTPReload(false);
    sensor.setResolution(true);
   int error=1,mj=0;
    //while(pc.scanf("%d",&mj)==0);
     
    pc.printf("Mbed Wireless Temperature Sensor\n\n\n");
    error = wifly.init(); // use DHCP
   
    if(error<0) 
    { pc.printf("Error in Initialization");
    }
    while (!wifly.connect()); // join the network
   
    printf("IP Address Obtained from Wireless Router %s\n\r", wifly.getIPAddress());
       
        TCPSocketConnection socket;
        while (socket.connect(ECHO_SERVER_ADDRESS, ECHO_SERVER_PORT) < 0) {
        printf("Unable to connect to (%s) on port (%d)\r\n", ECHO_SERVER_ADDRESS, ECHO_SERVER_PORT);
        wait(1);
    }
    
    int len = strlen(out_buffer);
     int j=  socket.send_all(out_buffer, len);
     pc.printf("no. of bytes sent [%d]\n",j);
    
     TCPSocketServer server;
    server.bind(5001);
    server.listen();
    
     while (true) {
        printf("\nWait for new connection...\n");
        TCPSocketConnection client;
        server.accept(client);
      //  client.set_blocking(false, 1500); // Timeout after (1.5)s
           sensor.update();
            float a=1.0;
            sensor.setScale(true);
        printf("Connection from: %s\n", client.get_address());
        
            int n=0;
            char buffer[255]="";
            //while(1) 
           {
       //     n = client.receive(buffer, sizeof(buffer));
            
         //   if(n>0)
            {
             
                          buffer[n+1]='\0';
             pc.printf("Byte[%d] %s\n",n,buffer);
            
           pc.printf("Temperature [ %3.2f F ]\r\n", sensor.getTemperature());
                      
           char out_buffer[] = "Temperature:\n";
           sprintf(temp,"%f",sensor.getTemperature());
           client.send_all(temp, sizeof(temp));
    
           wait_ms(100);
           client.close();
          //  break;
            }
    }
    }
    }
    
    